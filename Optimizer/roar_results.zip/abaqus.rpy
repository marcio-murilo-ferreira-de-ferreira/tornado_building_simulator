# -*- coding: mbcs -*-
#
# Abaqus/CAE Release 2024 replay file
# Internal Version: 2023_09_21-08.55.25 RELr426 190762
# Run by mmf6346 on Wed Mar 18 02:23:18 2026
#

# from driverUtils import executeOnCaeGraphicsStartup
# executeOnCaeGraphicsStartup()
#: Executing "onCaeGraphicsStartup()" in the site directory ...
from abaqus import *
from abaqusConstants import *
session.Viewport(name='Viewport: 1', origin=(1.36719, 1.36719), width=201.25, 
    height=135.625)
session.viewports['Viewport: 1'].makeCurrent()
from driverUtils import executeOnCaeStartup
executeOnCaeStartup()
execfile('abaqus_run_N.py', __main__.__dict__)
#: The model "NoRetrofitBaseline" has been created.
#: The interaction property "IntProp" has been created.
#: The interaction "GeneralContact" has been created.
#: Warning: The following loads are applied to empty regions.
#: These regions may have been invalidated by changes
#: to your model.
#: 
#:     Uplift
print('RT script done')
#: RT script done
