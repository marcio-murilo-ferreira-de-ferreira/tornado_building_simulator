import streamlit as st
import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from abaqus_generator import generate_abaqus_script
from chrono_generator import generate_chrono_script

# Set page config
st.set_page_config(
    page_title="Masonry Wall Simulator",
    page_icon="🧱",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for modern styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0px;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #4B5563;
        margin-bottom: 2rem;
    }
    .stSlider > div > div > div > div {
        background-color: #3B82F6;
    }
    .section-title {
        font-size: 1.8rem;
        font-weight: 600;
        color: #1F2937;
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-bottom: 2px solid #E5E7EB;
        padding-bottom: 0.5rem;
    }
    
    /* Increase base text and markdown sizes */
    .stMarkdown, p, div[data-testid="stMarkdownContainer"] {
        font-size: 1.2rem !important;
    }
    
    /* Increase Slider Labels and Input Labels */
    .stSlider label, .stRadio label, .stToggle label, .stTextInput label, div[data-testid="stWidgetLabel"] p {
        font-size: 1.3rem !important;
        font-weight: 500 !important;
    }
    
    /* Increase Slider numbering and values and Fix Spacing */
    div[data-testid="stThumbValue"], div[data-testid="stTickBarMax"], div[data-testid="stTickBarMin"], div.st-af {
        font-size: 1.1rem !important;
        font-weight: 600 !important;
    }
    
    /* Add extra margin below slider numbers to push them up off the bar */
    div[data-testid="stThumbValue"] {
        margin-bottom: 8px !important;
        transform: translateY(-8px) !important; /* Pull it further up */
    }
    
    /* Thicken the Slider Track (Rail and Fill) */
    .stSlider > div > div > div > div {
        height: 6px !important;  /* Active filled blue portion */
    }
    div[data-baseweb="slider"] > div > div:first-child {
        height: 6px !important;  /* Gray background rail */
        border-radius: 4px;
    }
    
    /* Increase Button text */
    button p {
        font-size: 1.2rem !important;
    }
    
    /* Scale radio options */
    div[role="radiogroup"] label {
        font-size: 1.1rem !important;
    }
</style>
""", unsafe_allow_html=True)

# Application Header
st.markdown('<div class="main-header">Abaqus/Chrono Masonry Wall Simulator</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Parametric generation of CDP and Rigid-Body dynamic simulation scripts</div>', unsafe_allow_html=True)

# Layout with two main columns
input_col, script_col, plot_col = st.columns([1.2, 1.2, 1.5])

with input_col:
    st.markdown('<div class="section-title">Model Approach</div>', unsafe_allow_html=True)
    model_type = st.radio("Select Modeling Strategy", ["1. Parede lisa (Macro-model)", "2. Parede em tijolos contrafiados (Meso-model)"])

    st.markdown('<div class="section-title">Wall Geometry</div>', unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        wall_height = st.slider("Wall Height (m)", min_value=2.0, max_value=6.0, value=3.0, step=0.1)
    with col2:
        wall_width = st.slider("Wall Width (m)", min_value=2.0, max_value=10.0, value=5.0, step=0.1)
        
    if "Macro-model" in model_type:
        wall_thickness = st.slider("Wall Thickness (m)", min_value=0.1, max_value=0.6, value=0.2, step=0.05)
        # Default empty brick params so they are always defined
        brick_length, brick_height, brick_depth, mortar_thickness, wythes = 0.2, 0.06, 0.1, 0.01, 1
    else:
        st.markdown("**Brick & Mortar Properties (Historic Pennsylvania Default)**")
        b_col1, b_col2, b_col3, b_col4 = st.columns(4)
        with b_col1:
            brick_length = st.number_input("Brick Length (m)", value=0.203, step=0.001, format="%.3f")
        with b_col2:
            brick_height = st.number_input("Brick Height (m)", value=0.057, step=0.001, format="%.3f")
        with b_col3:
            brick_depth = st.number_input("Brick Depth (m)", value=0.095, step=0.001, format="%.3f")
        with b_col4:
            mortar_thickness = st.number_input("Mortar Thick (m)", value=0.010, step=0.001, format="%.3f")
            
        wythes = st.slider("Number of Wythes (Camadas de espessura)", min_value=1, max_value=4, value=2, step=1)
        # Calculate wall thickness based on brick wythes and mortar joints between them
        wall_thickness = wythes * brick_depth + max(0, wythes - 1) * mortar_thickness
        st.info(f"Calculated 3D Wall Thickness: **{wall_thickness:.3f} m**")

    st.markdown('<div class="section-title">Openings (Windows/Doors)</div>', unsafe_allow_html=True)
    has_window = st.toggle("Include Window Opening", value=True)
    
    if has_window:
        w_col1, w_col2, w_col3, w_col4 = st.columns(4)
        with w_col1:
            window_width = st.slider("Window Width (m)", min_value=0.5, max_value=wall_width-1.0, value=1.0, step=0.1)
        with w_col2:
            window_height = st.slider("Window Height (m)", min_value=0.5, max_value=wall_height-1.0, value=1.2, step=0.1)
        with w_col3:
            sill_height = st.slider("Sill Height (m)", min_value=0.0, max_value=wall_height-window_height-0.2, value=0.9, step=0.1)
        with w_col4:
            max_offset = max(0.0, wall_width - window_width)
            default_offset = max_offset / 2.0
            window_offset_x = st.slider("X Offset (m)", min_value=0.0, max_value=max_offset, value=default_offset, step=0.1)
    else:
        window_width = 0.0
        window_height = 0.0
        sill_height = 0.0
        window_offset_x = 0.0

    st.markdown('<div class="section-title">Lateral Wind Load</div>', unsafe_allow_html=True)
    st.info("Wind pressure is converted to nodal/face loads applied to the surface.")
    
    tornado_class = st.selectbox("Tornado Wind Class (ASCE/EF Scale)", 
                                 ["Manual Input", 
                                  "EF-0 (Weak, ~0.8 kPa)", 
                                  "EF-1 (Moderate, ~1.5 kPa)", 
                                  "EF-2 (Significant, ~2.5 kPa)", 
                                  "EF-3 (Severe, ~4.0 kPa)", 
                                  "EF-4 (Devastating, ~6.0 kPa)", 
                                  "EF-5 (Incredible, ~8.5 kPa)"])
                                  
    if tornado_class == "Manual Input":
        wind_pressure = st.slider("Wind Pressure (kPa)", min_value=0.0, max_value=10.0, value=1.5, step=0.1)
    else:
        # Extract the approximate numerical value from the string
        pressure_val = float(tornado_class.split('~')[1].split(' ')[0])
        wind_pressure = st.slider("Wind Pressure (kPa)", min_value=0.0, max_value=10.0, value=pressure_val, step=0.1, disabled=True)
        
    wind_direction = st.radio("Wind Direction", ["Out-of-plane (perpendicular to wall)", "In-plane (parallel to wall)"], horizontal=True)
    
    st.markdown('<div class="section-title">Structural Retrofit</div>', unsafe_allow_html=True)
    apply_frp = st.toggle("Apply FRP Retrofit (Carbon Fiber Strips)", value=False)
    if apply_frp:
        frp_spacing = st.slider("FRP Strip Spacing (m)", min_value=0.5, max_value=2.0, value=1.0, step=0.1)

with plot_col:
    st.markdown('<div class="section-title">2D Schematic Preview</div>', unsafe_allow_html=True)
    
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Draw the main wall
    wall_rect = patches.Rectangle((0, 0), wall_width, wall_height, linewidth=2, edgecolor='#1E3A8A', facecolor='#93C5FD', alpha=0.5)
    ax.add_patch(wall_rect)
    
    # Draw the window if exists
    if has_window:
        w_x = window_offset_x
        w_y = sill_height
        window_rect = patches.Rectangle((w_x, w_y), window_width, window_height, linewidth=2, edgecolor='#DC2626', facecolor='white', hatch='//')
        ax.add_patch(window_rect)
        
        # Annotations for window
        ax.annotate(f"{window_width:.1f}m x {window_height:.1f}m", (w_x + window_width/2, w_y + window_height/2), color='#DC2626', weight='bold', ha='center', va='center')
    
    # Base support (Engaste)
    base_rect = patches.Rectangle((-0.5, -0.2), wall_width + 1.0, 0.2, linewidth=1, edgecolor='#4B5563', facecolor='#4B5563', hatch='\\\\')
    ax.add_patch(base_rect)
    
    ax.set_xlim(-1.0, wall_width + 1.0)
    ax.set_ylim(-0.5, wall_height + 1.0)
    ax.set_aspect('equal')
    ax.set_xlabel("Width (m)")
    ax.set_ylabel("Height (m)")
    ax.set_title("Frontal View of Masonry Wall Template", fontweight='bold')
    ax.grid(True, linestyle='--', alpha=0.6)
    
    st.pyplot(fig, use_container_width=True)
with script_col:
    st.markdown('<div class="section-title">Simulation Scripts Generation</div>', unsafe_allow_html=True)
    
    st.write("Review the parameters and generate the Python scripts for Abaqus and Project Chrono. The generated models will feature a perfectly fixed base (engaste) and facilitate correlation between Abaqus crack mapping and Chrono failure initiation.")
    
    st.markdown("---")
    
    
    st.subheader("1. Finite Element Analysis (CAE)")
    st.info("Generates macro to build the masonry wall with Concrete Damage Plasticity (CDP), fixed base support, and applied surface pressure.")
    
    # Abaqus Specific Controls
    def_scale_factor = st.slider("Deformation Scale Factor (Visual)", min_value=0.0, max_value=1000.0, value=100.0, step=10.0, 
                                 help="Scales the visual deformation in the output images. 0 means undeformed, 1 is true scale, >1 exaggerates the bending.")
    
    # Set Abaqus parameters natively
    params_abaqus = {
        'model_type': model_type,
        'brick_length': brick_length,
        'brick_height': brick_height,
        'brick_depth': brick_depth,
        'mortar_thickness': mortar_thickness,
        'wythes': wythes,
        'wall_width': wall_width,
        'wall_height': wall_height,
        'wall_thickness': wall_thickness,
        'has_window': has_window,
        'window_width': window_width,
        'window_height': window_height,
        'sill_height': sill_height,
        'window_offset_x': window_offset_x,
        'wind_pressure': wind_pressure * 1000.0, # Convert kPa to Pa for Abaqus
        'wind_direction': wind_direction,
        'def_scale_factor': def_scale_factor
    }
    
    abaqus_script_data = generate_abaqus_script(params_abaqus)
    
    st.download_button(
        label="1. Generate & Download Abaqus Macro",
        data=abaqus_script_data,
        file_name="abaqus_macro.py",
        mime="text/plain",
        use_container_width=True
    )
    
    st.markdown("---")
    st.write("**Or run automatically in the background:**")
    abaqus_cmd_path = st.text_input("Abaqus Command Path (if not in System PATH)", value=r"C:\SIMULIA\Commands\abaqus.bat", help="Leave as 'abaqus' if it's already in your Windows Environment Variables.")
    
    if st.button("2. Run Abaqus Simulation Headless", use_container_width=True, type="primary"):
        with st.spinner("Executing Abaqus CDP Analysis... This might take a few minutes!"):
            import subprocess
            
            # 1. Ensure directory exists
            run_dir = r"C:\Abaqus_Scripts\Parede_Cenario_01"
            os.makedirs(run_dir, exist_ok=True)
            
            # 2. Get the auto-run script
            abaqus_auto_script_data = generate_abaqus_script(params_abaqus, auto_run=True)
            script_path = os.path.join(run_dir, "abaqus_auto_macro.py")
            with open(script_path, "w", encoding='utf-8') as f:
                f.write(abaqus_auto_script_data)
            
            # 3. Clean up previous output and images to avoid showing old data or hanging on overwrite prompts
            for img in ["damaget_result.png", "mises_result.png", "u3_result.png"]:
                img_path = os.path.join(run_dir, img)
                if os.path.exists(img_path):
                    try:
                        os.remove(img_path)
                    except:
                        pass
                    
            for ext in ['.odb', '.dat', '.msg', '.sta', '.com', '.sim', '.prt', '.log', '.lck']:
                old_file = os.path.join(run_dir, f"MasonryWallJob{ext}")
                if os.path.exists(old_file):
                    try:
                        os.remove(old_file)
                    except:
                        pass
            
            # 4. Run Abaqus via CLI
            # We use abaqus cae noGUI to run scripts silently and write ODB results to image
            # Use the user-provided path or default 'abaqus'
            executable = abaqus_cmd_path.strip() if abaqus_cmd_path.strip() else "abaqus"
            cmd = [executable, "cae", f"noGUI={script_path}"]
            try:
                process = subprocess.run(cmd, cwd=run_dir, capture_output=True, text=True, check=True)
                st.markdown("<br><br><hr><br>", unsafe_allow_html=True)
                st.success("Analysis completed! ODB Maps projected below:")
                st.markdown("<br>", unsafe_allow_html=True)
                
                cols = st.columns(3)
                
                if os.path.exists(os.path.join(run_dir, "mises_result.png")):
                    cols[0].image(os.path.join(run_dir, "mises_result.png"), caption="S, Mises Stress")
                    
                if os.path.exists(os.path.join(run_dir, "damaget_result.png")):
                    cols[1].image(os.path.join(run_dir, "damaget_result.png"), caption="Tensile Damage (DAMAGET)")
                    
                if os.path.exists(os.path.join(run_dir, "u3_result.png")):
                    cols[2].image(os.path.join(run_dir, "u3_result.png"), caption="Out-of-Plane Disp (U3)")
                    
                if not any(os.path.exists(os.path.join(run_dir, img)) for img in ["damaget_result.png", "mises_result.png", "u3_result.png"]):
                    st.warning("Abaqus finished but no expected images were generated. Check the run directory or the log.")
                    with st.expander("Abaqus Output Log"):
                        st.code(process.stdout)
            
            except subprocess.CalledProcessError as e:
                st.error(f"Abaqus Execution Failed (Exit Code: {e.returncode})")
                with st.expander("Error Log"):
                    st.code(e.stderr + "\n" + e.stdout)
            except FileNotFoundError:
                st.error("Abaqus command not found in your system PATH. Please ensure the Abaqus commands folder is added to Windows Environment Variables, or use the Download Macro button instead.")
        
    st.markdown('---')
    st.subheader("2. Rigid-Body Dynamics")
    st.write("**Software:** Project Chrono")
    st.write("**Method:** Non-Smooth Contact (NSC)")
    st.write("**Goal:** Simulate discrete collapse mechanism")
    params_chrono = {
        'model_type': model_type,
        'brick_length': brick_length,
        'brick_height': brick_height,
        'brick_depth': brick_depth,
        'mortar_thickness': mortar_thickness,
        'wythes': wythes,
        'wall_height': wall_height, 'wall_width': wall_width, 'wall_thickness': wall_thickness,
        'has_window': has_window, 'window_width': window_width, 'window_height': window_height,
        'sill_height': sill_height, 'window_offset_x': window_offset_x, 
        'wind_pressure': wind_pressure, 'wind_direction': wind_direction,
        'apply_frp': apply_frp if 'apply_frp' in locals() else False
    }
    chrono_script_data = generate_chrono_script(params_chrono)
    
    st.download_button(
        label="Generate & Download PyChrono Script",
        data=chrono_script_data,
        file_name="pychrono_sim.py",
        mime="text/plain",
        use_container_width=True,
        type="primary"
    )


